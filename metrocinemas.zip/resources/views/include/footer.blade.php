
<footer><a href="#">Metrocinemas</a><a href="#">Aviso de privacidad</a>
  <script src="{{ mix('/js/manifest.js') }}" type="text/javascript"></script>
  <script src="{{ mix('/js/vendor.js') }}" type="text/javascript"></script>
  <script src="{{ mix('/js/general.js') }}" type="text/javascript"></script>
</footer>