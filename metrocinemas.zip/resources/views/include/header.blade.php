
<header><a href="/"><img src="/img/logo_metrocinemas.png"/></a>
  <form class="buscar" method="get" action="/buscar">
    <input type="text" name="q" placeholder="Buscar Película..." required="required"/>
    <button type="submit"><i class="fas fa-search"></i></button>
  </form>
  <nav>
    <ul>
      <li><a href="/">Inicio</a></li>
      <li><a href="cartelera">Cartelera</a></li>
    </ul>
  </nav>
</header>