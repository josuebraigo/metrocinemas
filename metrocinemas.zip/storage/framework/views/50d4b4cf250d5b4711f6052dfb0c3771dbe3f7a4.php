<!-- This file is used to store topbar (right) items -->


<?php /**PATH C:\xampp\htdocs\metrocinemas\resources\views/vendor/backpack/base/inc/topbar_right_content.blade.php ENDPATH**/ ?>