<!-- This file is used to store sidebar items, starting with Backpack\Base 0.9.0 -->
<!-- <li><a href="<?php echo e(backpack_url('dashboard')); ?>"><i class="fa fa-dashboard"></i> <span><?php echo e(trans('backpack::base.dashboard')); ?></span></a></li> -->
<!-- <li><a href="<?php echo e(backpack_url('elfinder')); ?>"><i class="fa fa-files-o"></i> <span><?php echo e(trans('backpack::crud.file_manager')); ?></span></a></li> -->
<li><a href='<?php echo e(backpack_url('actor')); ?>'><i class='fa fa-male'></i><span>Actores</span></a></li>
<li><a href='<?php echo e(backpack_url('director')); ?>'><i class='fa fa-user'></i><span>Directores</span></a></li>
<li><a href='<?php echo e(backpack_url('movie')); ?>'><i class='fa fa-film'></i><span>Películas</span></a></li>
<li><a href='<?php echo e(backpack_url('function')); ?>'><i class='fa fa-ticket'></i> <span>Funciones</span></a></li>
<li><a href='<?php echo e(backpack_url('room')); ?>'><i class='fa fa-th'></i> <span>Salas</span></a></li>
<li><a href='<?php echo e(backpack_url('genre')); ?>'><i class='fa fa-flag'></i> <span>Género</span></a></li><?php /**PATH C:\xampp\htdocs\metrocinemas\resources\views/vendor/backpack/base/inc/sidebar_content.blade.php ENDPATH**/ ?>